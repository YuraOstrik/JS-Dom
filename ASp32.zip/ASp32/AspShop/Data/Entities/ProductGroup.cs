﻿namespace Practica_Shop.Data.Entities
{
    public class ProductGroup
    {
        public Guid Id { get; set; }
        public Guid? ParentId { get; set; }
        public String Name { get; set; } = null!;
        public String Description { get; set; } = null!;
        public String Slug {  get; set; } = null!;
        public String ImgeUrl { get; set; } = null!;
        public DateTime? DeleteAt { get; set; }

        public ICollection<Product> Products { get; set; } = [];

    }
}

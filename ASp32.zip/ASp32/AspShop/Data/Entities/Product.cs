﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Practica_Shop.Data.Entities
{
    public class Product
    {
        public Guid Id { get; set; }
        public Guid GroupId { get; set; }
        public string Name { get; set; } = null!;
        public String? Description { get; set; } = null!;
        public String Slug { get; set; } = null!;
        public String ImgeUrl { get; set; } = null!;
        public int Stok {  get; set; }
        [Column(TypeName ="decimal(12,2)")]
        public double Price { get; set; }
        public DateTime? DeleteAt { get; set; }

        public ProductGroup Group { get; set; } = null!;
    }
}

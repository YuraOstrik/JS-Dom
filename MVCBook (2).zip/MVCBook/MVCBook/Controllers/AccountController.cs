﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MVCBook.Models;
using MVCBook.Password;
using MVCBook.Repository;
using System.Security.Cryptography;
using System.Text;

namespace MVCBook.Controllers
{
    public class AccountController : Controller
    {
        private readonly IRepository _repository;
        private readonly IPassword _passwordHasher;

        public AccountController(IRepository repository, IPassword passwordHasher)
        {
            _repository = repository;
            _passwordHasher = passwordHasher;
        }

        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LogIn logon)
        {
            if (!ModelState.IsValid) return View(logon);

            var user = _repository.Users.FirstOrDefault(u => u.FullName == logon.Login);
            if (user == null)
            {
                ModelState.AddModelError("", "Wrong login or password!");
                return View(logon);
            }

            string hashedInput = _passwordHasher.HashPassword(logon.Password, user.Salt);
            if (user.Pwd != hashedInput)
            {
                ModelState.AddModelError("", "Wrong login or password!");
                return View(logon);
            }

            HttpContext.Session.SetString("FullName", user.FullName);
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(Registration reg)
        {
            if (!ModelState.IsValid) return View(reg);

            var user = new Users
            {
                FullName = reg.FirstName + " " + reg.LastName
            };

            string salt = _passwordHasher.GenerateSalt();
            string hash = _passwordHasher.HashPassword(reg.Password, salt);

            user.Salt = salt;
            user.Pwd = hash;

            _repository.AddUser(user);
            await _repository.SaveAsync();

            return RedirectToAction("Login");
        }
    }

}

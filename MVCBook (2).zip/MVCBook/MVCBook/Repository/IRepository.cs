﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Win32;
using MVCBook.Controllers;
using MVCBook.Models;

namespace MVCBook.Repository
{
    public interface IRepository
    {
        IQueryable<Users> Users { get; }
        IQueryable<Messages> Messages { get; }

        void AddUser(Users user);
        void AddMessage(Messages message);
        Task SaveAsync();


    }
}

﻿namespace MVCBook.Models
{
    public class Users
    {
        public int? Id { get; set; }
        public string? FullName { get; set; }
        public string? Pwd { get; set; }

        public string? Salt { get; set; }
        public ICollection<Messages> Message { get; set; } = new List<Messages>();

    }
}

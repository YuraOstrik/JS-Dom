﻿namespace MVCBook.Models
{
    public class Messages
    {
        public int Id { get; set; }
        public int? User_Id { get; set; }
        public string? Text { get; set; }
        public DateTime? MessagesDate { get; set; }

        public Users? User { get; set; }
    }
}

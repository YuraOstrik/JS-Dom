﻿using System.Security.Cryptography;
using System.Text;

namespace MVCBook.Password
{
    public class PasswordHasher : IPassword
    {
        public string GenerateSalt(int size = 16)
        {
            byte[] saltBytes = new byte[size];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(saltBytes);

            return BitConverter.ToString(saltBytes).Replace("-", "");
        }

        public string HashPassword(string password, string salt)
        {
            byte[] passwordBytes = Encoding.Unicode.GetBytes(salt + password);
            using var md5 = MD5.Create();
            byte[] hashBytes = md5.ComputeHash(passwordBytes);
            return BitConverter.ToString(hashBytes).Replace("-", "");
        }
    }
}

using Microsoft.EntityFrameworkCore;
using MusicalShop.Data;
using MusicalShop.Data.Entities;
using MusicalShop.Middleware.Auth;
using MusicalShop.Services.Auth;
using MusicalShop.Services.Kdi;
using MusicalShop.Services.Storage;
using System.Security.Cryptography;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<IKdiService, PbKdfService>();
builder.Services.AddDbContext<DataContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5,
                maxRetryDelay: TimeSpan.FromSeconds(10),
                errorNumbersToAdd: null
            );
        }));

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(10);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<IAuthService, SessionAuthService>();

builder.Services.AddSingleton<IStorageService, DiskStorageService>();
static string GenerateSalt()
{
    byte[] saltBytes = new byte[8];
    using var rng = RandomNumberGenerator.Create();
    rng.GetBytes(saltBytes);
    return Convert.ToHexString(saltBytes);
}

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();



app.UseSession();
app.UseSessionAuth();



app.UseAuthorization();





app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

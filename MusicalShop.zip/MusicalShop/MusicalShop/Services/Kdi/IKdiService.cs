﻿namespace MusicalShop.Services.Kdi
{
    public interface IKdiService
    {
        String Dk(String password, String salt);
        String GenerateSalt();
    }
}

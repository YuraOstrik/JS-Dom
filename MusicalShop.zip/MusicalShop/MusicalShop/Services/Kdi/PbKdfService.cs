﻿using System.Security.Cryptography;

namespace MusicalShop.Services.Kdi
{
    public class PbKdfService : IKdiService
    {
        const int c = 3;
        const int dkLen = 20;

        public String Dk(String password, String salt)
        {
            String t = Hash(password + salt);
            for (int i = 0; i < c - 1; i++) {
                t = Hash(t);
            }
            return t[..dkLen];
        }

        public String GenerateSalt()
        {
            byte[] saltBytes = RandomNumberGenerator.GetBytes(8);
            return Convert.ToHexString(saltBytes);
        }

        private static String Hash(String input) => Convert.ToHexString(
            System.Security.Cryptography.SHA1.HashData(
                System.Text.Encoding.UTF8.GetBytes(input)));

    }
}

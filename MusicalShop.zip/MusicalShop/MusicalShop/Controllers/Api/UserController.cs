﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusicalShop.Data;
using MusicalShop.Services.Auth;
using MusicalShop.Services.Kdi;
using Microsoft.EntityFrameworkCore;
using MusicalShop.Models.Home;
using MusicalShop.Data.Entities;


namespace MusicalShop.Controllers.Api
{
    [Route("api/user")]
    [ApiController]
    public class UserController(
            DataContext dataContext,
            IKdiService kdfService,
            IAuthService authService) : ControllerBase
    {
        private readonly DataContext _dataContext = dataContext;
        private readonly IKdiService _kdfService = kdfService;
        private readonly IAuthService _authService = authService;

        [HttpGet]
        public object Authenticate()
        {
            String? header = HttpContext.Request.Headers.Authorization;
            if (header == null)     
            {
                HttpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return new { Status = "Authorization Header Required" };
            }

            String credentials =    
                header[6..];        
            String userPass =       
                System.Text.Encoding.UTF8.GetString(
                    Convert.FromBase64String(credentials));

            String[] parts = userPass.Split(':', 2);
            String login = parts[0];
            String password = parts[1];

            var userAccess = _dataContext
                .UserAccesses
                .AsNoTracking()
                .Include(ua => ua.User)
                .Include(ua => ua.Role)
                .FirstOrDefault(ua => ua.Login == login);

            if (userAccess == null)
            {
                HttpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return new { Status = "Credentials rejected" };
            }
            String dk = _kdfService.Dk(password, userAccess.Salt);
            if (dk != userAccess.Dk)
            {
                HttpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return new { Status = "Credentials rejected." };
            }
            // зберігаємо у сесії факт успішної автентифікації
            // HttpContext.Session.SetString(
            //     "UserController::Authenticate",
            //     JsonSerializer.Serialize(userAccess)
            // );
            _authService.SetAuth(userAccess);
            return userAccess;
        }


        [HttpPost]
        public object SignUp([FromForm] UserViewModel model)
        {
            if(!ModelState.IsValid)
            {
                HttpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
                return new { Status = "Model is not valid" };
            }
            if(_dataContext.Users.Any(u => u.Email == model.Email))
            {
                HttpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
                return new { Status = "Email is already registered" };
            }
            if (model.Password != model.PasswordConfirm)
            {
                HttpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
                return new { Status = "Password do not match" };
            }
                

            var role = _dataContext.UserRoles.FirstOrDefault(r => r.Description == "User");
            if(role == null)
            {
                HttpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;
                return new { Status = "Role 'User' is not found" };
            }
            var salt = _kdfService.GenerateSalt();
            var dk = _kdfService.Dk(model.Password, salt);

            var user = new User
            {
                Id = Guid.NewGuid(),
                Name = model.Name,
                Email = model.Email,
                Birthdate = model.Birthdate
            };

            _dataContext.Users.Add(user);

            var access = new UserAccess
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                Login = model.Login,
                Salt = salt,
                Dk = dk,
                RoleId = role.Id
            };

            _dataContext.UserAccesses.Add(access);
            _dataContext.SaveChanges();

            return new { Status = "SingUpUser Works", code = 200};
        }

        [HttpPost("admin")]  // POST /api/user/admin
        public object SignUpAdmin()
        {
            return new { Status = "SignUpAdmin Works" };
        }
    }
}

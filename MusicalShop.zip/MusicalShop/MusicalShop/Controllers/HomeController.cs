using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicalShop.Data;
using MusicalShop.Data.Entities;
using MusicalShop.Models;
using MusicalShop.Models.Home;
using MusicalShop.Services.Kdi;
using MusicalShop.Services.Storage;
using System;
using System.Diagnostics;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace MusicalShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IKdiService _kdfService;
        private readonly DataContext _dataContext;
        private readonly IStorageService _storageService;

        public HomeController(ILogger<HomeController> logger, IKdiService kdfService, DataContext dataContext, IStorageService storageService)
        {
            _logger = logger;
            _kdfService = kdfService;
            _dataContext = dataContext;
            _storageService = storageService;
        }

        public IActionResult Index(string? genre)
        {
            var genres = _dataContext.Genres
            .Where(g => g.CreatedBy != null)
            .Select(g => g.Name)
            .ToList();

            var songsQuery = _dataContext.Songs
                .Include(s => s.Genre)
                .AsQueryable();

            if (!string.IsNullOrEmpty(genre))
            {
                songsQuery = songsQuery.Where(s => s.Genre.Name == genre);
            }

            var songs = songsQuery
                .AsEnumerable()
                .Select(s => new SongViewModel
                {
                    Id = s.Id,
                    UserId = s.UserId.ToString(),
                    Name = s.Name,
                    Text = s.Text,
                    GenreName = s.Genre.Name,
                    FileUrl = s.FilePath
                })
                .ToList();

            var model = new IndexViewModel
            {
                Genres = genres,
                Songs = songs,
                SelectedGenre = genre
            };

            return View(model);
        }

        public IActionResult Category(String id)
        {
            //HomeCategoryViewModel model = new()
            //{
            //    ProductGroup = _dataContext
            //    .ProductGroups
            //    .Include(g => g.Products)
            //    .AsNoTracking()
            //    .FirstOrDefault(g => g.Slug == id && g.DeletedAt == null)
            //};
            //return View(model);
            return View();
        }

        public IActionResult Admin()
        {
            bool isAdmin = HttpContext.User.Claims
                .FirstOrDefault(c => c.Type == ClaimTypes.Role)
                ?.Value == "Admin";

            bool isUser = HttpContext.User.Claims
                .FirstOrDefault(c => c.Type == ClaimTypes.Role)
                ?.Value == "User";

            if (isAdmin || isUser)
            {
                AdminViewModel model = new()
                {
                    Genres = _dataContext
                    .Genres.Where(g => g.CreatedBy != null)
                    .AsEnumerable(),

                };

                return View(model);
            }
            else
            {
                return RedirectToAction(nameof(Index));
            }
        }
        public IActionResult Registration(UserViewModel model)
        {
            return View(model);
        }

        public IActionResult AboutSong(string songId)
        {
            if (!Guid.TryParse(songId, out var guid))
                return BadRequest("Invalide songId");

            var song = _dataContext.Songs.FirstOrDefault(s => s.Id == guid);

            if (song == null)
                return NotFound("Song do not found");

            var songModel = new SongViewModel
            {
                Id = song.Id,
                Name = song.Name,
                FileUrl = song.FilePath,
                Text = song.Text
                    .Replace("[Verse]", "<strong>[Verse]</strong>")
                    .Replace("[Chorus]", "<strong>[Chorus]</strong>")
                    .Replace("\n", "<br/>")
            };

            return View(songModel);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

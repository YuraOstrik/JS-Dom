﻿using System.ComponentModel.DataAnnotations;

namespace MusicalShop.Models.Home
{
    public class UserViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
        public string Email { get; set; } = null!;
        public DateTime? Birthdate { get; set; }
        [Required(ErrorMessage = "Login is required")]
        public string Login { get; set; } = null!;
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; } = null!;

        [Compare("Password", ErrorMessage = "Passwords do not match")]
        public string PasswordConfirm { get; set; } = null!;
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace MusicalShop.Models.Home
{
    public class GenreForModel
    {
        [FromForm(Name = "genre-name")]
        public String Name { get; set; } = null!;
    }
}

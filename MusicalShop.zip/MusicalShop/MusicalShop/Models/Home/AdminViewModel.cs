﻿using MusicalShop.Data.Entities;

namespace MusicalShop.Models.Home
{
    public class AdminViewModel
    {
        public IEnumerable<Genre> Genres { get; set; }
        public IEnumerable<SongViewModel> Songs { get; set; } = [];
    }
}

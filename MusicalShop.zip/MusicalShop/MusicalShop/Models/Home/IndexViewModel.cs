﻿using MusicalShop.Data.Entities;

namespace MusicalShop.Models.Home
{
    public class IndexViewModel
    {
        public IEnumerable<string> Genres { get; set; } = [];
        public IEnumerable<SongViewModel> Songs { get; set; } = [];
        public string? SelectedGenre { get; set; }
    }
}

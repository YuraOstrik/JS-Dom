﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusicalShop.Data;
using MusicalShop.Data.Entities;
using MusicalShop.Services.Auth;
using MusicalShop.Services.Storage;

namespace MusicalShop.Models.Home
{
    [Route("api/genre")]
    [ApiController]
    public class GenreController(DataContext dataContext, IAuthService authService) : ControllerBase
    {
        private readonly DataContext _dataContext = dataContext;
        private readonly IAuthService _authService = authService;

        [HttpPost]
        public object AddGenre(GenreForModel model)
        {
            var currentUser = _authService.GetAuth<UserAccess>();
            if (currentUser == null) {
                return new { status = "Unauthorized", code = 401 };
            }

            _dataContext.Genres.Add(new()
            {
                Name = model.Name,
                CreatedById = currentUser.User.Id,
                CreatedAt = DateTime.UtcNow
            });
            try
            {
                _dataContext.SaveChanges();
                return new { status = "OK", code = 200 };
            }
            catch (Exception ex)
            {
                return new { status = ex.Message, code = 500 };
            }
        }
    }
}

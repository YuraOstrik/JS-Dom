﻿using Microsoft.AspNetCore.Mvc;
namespace MusicalShop.Models.Api
{
    public class ApiSongFromModel
    {

        [FromForm(Name = "song-genre-id")]
        public String GenreId { get; set; } = null!;

        [FromForm(Name = "song-name")]
        public String Name { get; set; } = null!;
        [FromForm(Name = "song-text")]
        public String Text { get; set; } = null!;
        [FromForm(Name = "song-filepath")]
        public IFormFile? FilePath { get; set; } = null!;
    }
}

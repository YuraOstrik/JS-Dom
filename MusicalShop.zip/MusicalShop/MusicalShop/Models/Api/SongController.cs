﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicalShop.Data;
using MusicalShop.Data.Entities;
using MusicalShop.Services.Auth;
using MusicalShop.Services.Storage;

namespace MusicalShop.Models.Api
{
    [Route("api/song")]
    [ApiController]
    public class SongController(IStorageService storageService,
        DataContext dataContext,
        IAuthService authService) : ControllerBase
    {
        private readonly IStorageService _storageService = storageService;
        private readonly DataContext _dataContext = dataContext;
        private readonly IAuthService _authService = authService;

        [HttpPost]
        public object AddSong(ApiSongFromModel model)
        {
            Guid genreid;
            try
            {
                genreid = Guid.Parse(model.GenreId);
            }
            catch
            {
                return new { status = "Invalid GenreId", code = 400 };
            }
            var currentUser = _authService.GetAuth<UserAccess>();
            _dataContext.Songs.Add(new()
            {
                Id = Guid.NewGuid(),
                UserId = currentUser.User.Id,
                GenreId = genreid,
                Name = model.Name,
                Text = model.Text,
                FilePath = model.FilePath == null ? null : _storageService.Save(model.FilePath)
            });

            try
            {
                _dataContext.SaveChanges();
                return new { status = "OK", code = 200 };
            }
            catch (Exception ex)
            {
                return new { status = ex.Message, code = 500 };
            }

        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using MusicalShop.Data.Entities;
namespace MusicalShop.Data
{
    public class DataContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<UserAccess> UserAccesses { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<Song> Songs { get; set; }

        public DataContext(DbContextOptions options) : base(options) {
        
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserRole>().HasData(
                new UserRole
                {
                    Id = Guid.Parse("11111111-1111-1111-1111-111111111111"),
                    Description = "Admin",
                    CanCreate = true,
                    CanRead = true,
                    CanUpdate = true,
                    CanDelete = true
                },
                new UserRole
                {
                    Id = Guid.Parse("22222222-2222-2222-2222-222222222222"),
                    Description = "User",
                    CanCreate = true,
                    CanRead = true,
                    CanUpdate = false,
                    CanDelete = false
                },
                new UserRole
                {
                    Id = Guid.Parse("33333333-3333-3333-3333-333333333333"),
                    Description = "Guest",
                    CanCreate = false,
                    CanRead = true,
                    CanUpdate = false,
                    CanDelete = false
                }
            );

            modelBuilder.Entity<UserAccess>()
                .HasOne(ua => ua.User)
                .WithMany(u => u.Accesses)
                .HasForeignKey(ua => ua.UserId);

            modelBuilder.Entity<UserAccess>()
                .HasOne(ua => ua.Role)
                .WithMany(r => r.UserAccesses)
                .HasForeignKey(ua => ua.RoleId);

            modelBuilder.Entity<UserAccess>()
                .HasIndex(ua => ua.Login)
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasIndex(ua => ua.Email)
                .IsUnique();


            modelBuilder.Entity<Song>()
               .HasOne(s => s.User)
               .WithMany(u => u.Songs)
               .HasForeignKey(s => s.UserId)
               .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Song>()
                .HasOne(s => s.Genre)
                .WithMany(g => g.Songs)
                .HasForeignKey(s => s.GenreId)
                .OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<Genre>()
                 .HasIndex(g => g.Name)
                 .IsUnique();

            modelBuilder.Entity<Genre>()
                .HasOne(g => g.CreatedBy)
                .WithMany(u => u.Genres)
                .HasForeignKey(g => g.CreatedById)
                .OnDelete(DeleteBehavior.Restrict);

        }
    }
}

﻿using System.Text.Json.Serialization;

namespace MusicalShop.Data.Entities
{
    public class UserRole
    {
        public Guid Id { get; set; } 
        public String Description { get; set; } = null!;
        public bool CanCreate { get; set; }
        public bool CanRead {  get; set; }
        public bool CanUpdate { get; set; }
        public bool CanDelete { get; set; }
        [JsonIgnore]
        public ICollection<UserAccess> UserAccesses { get; set; } = [];
    }
}

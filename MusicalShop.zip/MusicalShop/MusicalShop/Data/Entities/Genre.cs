﻿using System.Text.Json.Serialization;

namespace MusicalShop.Data.Entities
{
    public class Genre
    {
        public Guid Id { get; set; }
        public Guid CreatedById { get; set; }
        public User CreatedBy { get; set; } = null!;
        public String Name { get; set; } = null!;
        public DateTime CreatedAt { get; set; }
        [JsonIgnore]
        public ICollection<Song> Songs { get; set; } = [];

    }
}

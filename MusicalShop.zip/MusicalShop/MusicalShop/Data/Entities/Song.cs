﻿namespace MusicalShop.Data.Entities
{
    public class Song
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public User User { get; set; }
        public Guid GenreId { get; set; } 
        public Genre Genre { get; set; }
        
        public String Name { get; set; } = null!;
        public String Text { get; set; } = null!;
        public String FilePath { get; set; } = null!;
    }
}
